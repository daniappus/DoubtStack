from django.apps import AppConfig


class DoubtstackConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'doubtstack'
