from django.shortcuts import render, redirect, get_object_or_404

def landing(request):
    return render(request, 'index/landing.html')

from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.utils.crypto import get_random_string
from . import models
from . import forms
from django.contrib.auth.hashers import make_password, check_password
from datetime import datetime

# Login/Register view with session management
def login_register_view(request):
    step = request.session.get('step', 'username')
    username = request.session.get('username', '')
    is_student = request.session.get('is_student', True)

    # STEP 1: Enter register/teacher number
    if step == 'username':
        form = forms.LoginForm(request.POST or None)
        if request.method == "POST" and form.is_valid():
            username_input = form.cleaned_data['username']
            request.session['username'] = username_input

            # Check if user exists in our system
            if models.Student.objects.filter(username=username_input).exists():
                request.session['is_student'] = True
                request.session['step'] = 'password'
                return redirect('login_register')
            elif models.Teacher.objects.filter(username=username_input).exists():
                request.session['is_student'] = False
                request.session['step'] = 'password'
                return redirect('login_register')
            else:
                # Check in college DB (LoginDB / LoginDB2)
                try:
                    if username_input.isdigit() and len(username_input) < 10:
                        col_student = models.LoginDB.objects.get(adm_no=username_input)
                        request.session['is_student'] = True
                        email = col_student.stu_email
                    else:
                        col_teacher = models.LoginDB2.objects.get(tchr_no=username_input)
                        request.session['is_student'] = False
                        email = col_teacher.tchr_email

                    # Send OTP
                    otp_code = get_random_string(length=6, allowed_chars='0123456789')
                    models.OTP.objects.update_or_create(username=username_input, defaults={"otp": otp_code})
                    masked_email = email[:2] + "****" + email[email.index("@"):]
                    request.session['masked_email'] = masked_email
                    send_mail(
                        "DoubtStack OTP Verification",
                        f"Your OTP is {otp_code}",
                        None,
                        [email],
                        fail_silently=False
                    )
                    request.session['step'] = 'otp'
                    return redirect('login_register')
                except:
                    messages.error(request, "User not found in college database!")

        return render(request, 'login_register.html', {'form': form, 'step': 'username'})

    # STEP 2: OTP verification
    elif step == 'otp':
        form = forms.OTPForm(request.POST or None)
        if request.method == "POST" and form.is_valid():
            otp_input = form.cleaned_data['otp']
            otp_obj = models.OTP.objects.filter(username=username).first()
            if otp_obj and otp_obj.otp == otp_input:
                request.session['step'] = 'password_create'
                return redirect('login_register')
            else:
                messages.error(request, "Invalid OTP!")
        return render(request, 'login_register.html', {'form': form, 'step': 'otp', 'masked_email': request.session.get('masked_email', '')})

    # STEP 3: Password creation for new account
    elif step == 'password_create':
        form = forms.PasswordForm(request.POST or None)
        if request.method == "POST" and form.is_valid():
            pw = form.cleaned_data['password']
            cpw = form.cleaned_data['confirm_password']
            if pw != cpw:
                messages.error(request, "Passwords do not match!")
            else:
                pw_encrypted = make_password(pw)
                # Fetch college details
                if request.session.get('is_student', True):
                    col_student = models.LoginDB.objects.get(adm_no=username)
                    sem = get_current_sem(col_student.stu_start_year, col_student.stu_end_year)
                    models.Student.objects.create(
                        student_id=col_student.adm_no,
                        username=username,
                        password=pw_encrypted,
                        name=col_student.stu_name,
                        department=col_student.stu_branch,
                        semester=sem
                    )
                else:
                    col_teacher = models.LoginDB2.objects.get(tchr_no=username)
                    models.Teacher.objects.create(
                        teacher_id=col_teacher.tchr_no,
                        username=username,
                        password=pw_encrypted,
                        name=col_teacher.tchr_name,
                        department=col_teacher.tchr_dept
                    )
                messages.success(request, "Account created! Please login now.")
                request.session['step'] = 'password'
                return redirect('login_register')
        return render(request, 'login_register.html', {'form': form, 'step': 'password_create'})

    # STEP 4: Existing user login
    elif step == 'password':
        form = forms.PasswordForm(request.POST or None)
        if request.method == "POST" and form.is_valid():
            pw = form.cleaned_data['password']
            try:
                if request.session.get('is_student', True):
                    user_obj = models.Student.objects.get(username=username)
                    dashboard = 'student_dashboard'
                else:
                    user_obj = models.Teacher.objects.get(username=username)
                    dashboard = 'teacher_dashboard'

                if check_password(pw, user_obj.password):
                    # LOGIN SUCCESS: Set session
                    request.session['user_id'] = user_obj.student_id if is_student else user_obj.teacher_id
                    request.session['username'] = username
                    request.session['is_student'] = is_student
                    request.session['logged_in'] = True

                    messages.success(request, "Login successful!")
                    return redirect(dashboard)
                else:
                    messages.error(request, "Incorrect password!")
            except:
                messages.error(request, "User not found!")
        return render(request, 'login_register.html', {'form': form, 'step': 'password'})


# DASHBOARD VIEWS

def student_dashboard(request):
    if not request.session.get('logged_in') or not request.session.get('is_student', False):
        return redirect('login_register')
    return render(request, 'student_dashboard.html', {'username': request.session.get('username')})

def teacher_dashboard(request):
    if not request.session.get('logged_in') or request.session.get('is_student', True):
        return redirect('login_register')
    return render(request, 'teacher_dashboard.html', {'username': request.session.get('username')})

# LOGOUT
def logout_view(request):
    request.session.flush()
    messages.success(request, "Logged out successfully!")
    return redirect('landing')

# HELPER: Current semester calculation
def get_current_sem(start_year, end_year):
    now = datetime.now()
    month = now.month
    sem = 1
    if month >= 9 or month <= 2:
        sem = 1
    elif 2 < month <= 6:
        sem = 2
    elif 6 < month <= 11:
        sem = 3
    elif 12 <= month <= 5:
        sem = 4
    return sem
