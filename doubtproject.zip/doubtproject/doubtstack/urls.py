from django.urls import path
from . import views

urlpatterns = [
    path('', views.landing, name='landing'),
    path('login', views.login_register_view, name='login_register'),
    path('student/', views.student_dashboard, name='student_dashboard'),
    path('teacher/', views.teacher_dashboard, name='teacher_dashboard'),
    path('logout/', views.logout_view, name='logout'),
]
